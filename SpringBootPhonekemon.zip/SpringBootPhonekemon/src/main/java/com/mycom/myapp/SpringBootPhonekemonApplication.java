package com.mycom.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPhonekemonApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPhonekemonApplication.class, args);
	}

}
