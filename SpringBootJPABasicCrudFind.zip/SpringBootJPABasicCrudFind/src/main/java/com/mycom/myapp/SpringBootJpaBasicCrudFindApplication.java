package com.mycom.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJpaBasicCrudFindApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootJpaBasicCrudFindApplication.class, args);
	}

}
